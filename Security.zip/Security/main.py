from Security.models.key_models.protocols.application_message import ApplicationMessage
from Security.models.key_models.protocols.commit import SignedCommit
from Security.models.user import User
from Security.services.group_services.group_service import GroupService
from Security.services.group_services.key_services.key_package_service import (
    KeyPackageService,
    TrustedIdentity,
)
from Security.services.group_services.key_services.tree_key_service import TreeKeyService
from Security.services.message_services.delivery_service import DeliveryService
from Security.services.message_services.message_service import MessageService
from Security.models.group_models.managed_group_state import ManagedGroupState


def main() -> None:
    packages = KeyPackageService()
    groups = GroupService(packages, TreeKeyService())
    messages = MessageService()
    delivery = DeliveryService()

    alice, bob, charlie, eve = (
        User(name.lower(), name) for name in ("Alice", "Bob", "Charlie", "Eve")
    )
    founder = groups.create_group(alice, "6200 Project Chat")
    group_id = founder.group_id
    members = [alice]

    def identity(user: User) -> TrustedIdentity:
        return TrustedIdentity(
            user.user_id.encode(),
            user.signing_key.public_key().public_bytes_raw(),
        )

    def announce(event: str) -> None:
        names = ", ".join(user.display_name for user in members)
        print(f"\nEpoch {founder.epoch} | {event} | Members: {names}")

    def deliver_commit(commit: SignedCommit, peers: list[User]) -> None:
        delivery.send_message([peer.user_id for peer in peers], commit)
        for peer in peers:
            received, = delivery.receive_messages(peer.user_id)
            if not isinstance(received, SignedCommit):
                raise RuntimeError("Expected a membership Commit.")

            state = peer.groups[group_id]
            if not isinstance(state, ManagedGroupState):
                raise RuntimeError(f"{peer.display_name} has no managed state for this group.")

            peer.groups[group_id] = groups.apply_commit(state, received)
            

    def add(user: User) -> None:
        nonlocal founder
        expected = identity(user)
        package, = packages.generate_packages(user, expected.credential, 1)
        result = groups.add_member(alice, founder, package, expected)

        # Existing members apply the Commit. The new member joins via Welcome.
        deliver_commit(result.commit, [peer for peer in members if peer is not alice])
        groups.accept_welcome(user, result.welcome, expected_inviter=identity(alice))
        founder = alice.groups[group_id] = result.state
        members.append(user)
        announce(f"Alice added {user.display_name}")

    def say(sender: User, text: str) -> ApplicationMessage:
        packet = messages.encrypt(sender, sender.groups[group_id], text)
        peers = [peer for peer in members if peer is not sender]
        delivery.send_message([peer.user_id for peer in peers], packet)

        for peer in peers:
            received, = delivery.receive_messages(peer.user_id)
            if not isinstance(received, ApplicationMessage):
                raise RuntimeError("Expected an application message.")
            if messages.decrypt(peer.groups[group_id], received) != text:
                raise RuntimeError(f"{peer.display_name} received a different message.")

        readers = ", ".join(peer.display_name for peer in peers)
        print(f"{sender.display_name}: {text}  [decrypted by {readers}]")
        count = founder.epoch_message_count
        print(f"  Epoch {founder.epoch} message count: {count}")
        if founder.rotation_due:
            rotate()
        return packet

    def rotate() -> None:
        nonlocal founder
        if not all(peer.groups[group_id].rotation_due for peer in members):
            raise RuntimeError("Not all members have processed the epoch messages.")
        previous_epoch = founder.epoch
        result = groups.rotate_epoch(alice, founder)
        deliver_commit(result.commit, [peer for peer in members if peer is not alice])
        founder = alice.groups[group_id] = result.state
        if not all(peer.groups[group_id].epoch == founder.epoch for peer in members):
            raise RuntimeError("Members did not advance to the same epoch.")
        announce(f"Automatic rotation: epoch {previous_epoch} -> {founder.epoch}")

    announce("Alice created the group")

    add(bob)
    say(alice, "Bob, can you see the chat?")
    say(bob, "Loud and clear.")
    say(alice, "I'll bring Charlie in.")

    add(charlie)
    say(charlie, "Hey everyone. What are we testing?")
    say(bob, "Whether we all receive each message.")
    say(alice, "Let's try it with four people.")

    add(eve)
    say(eve, "I'm here for the four-person test.")
    say(charlie, "I got your message, Eve.")
    say(bob, "Same here.")
    say(alice, "Thanks, Eve. That finishes your part.")
    say(bob, "This is message five in this epoch.")
    say(eve, "This is message six.")
    say(charlie, "Message seven triggers our key rotation.")
    say(alice, "Message eight uses the new epoch.")

    # Keep Eve's old state so the demo can check it against a new-epoch message.
    eve_state = eve.groups[group_id]
    result = groups.remove_member(alice, founder, eve_state.own_leaf_index)
    remaining = [peer for peer in members if peer is not eve]
    deliver_commit(result.commit, [peer for peer in remaining if peer is not alice])
    founder = alice.groups[group_id] = result.state
    members = remaining
    del eve.groups[group_id]
    announce("Alice removed Eve")

    packet = say(alice, "Can everyone remaining read this?")
    say(bob, "Yes, I received it.")
    say(charlie, "Me too. Demo complete.")

    try:
        messages.decrypt(eve_state, packet)
    except ValueError as error:
        print(f"Eve's old state rejected the new message: {error}")
    else:
        raise RuntimeError("Eve unexpectedly decrypted a post-removal message.")


if __name__ == "__main__":
    main()